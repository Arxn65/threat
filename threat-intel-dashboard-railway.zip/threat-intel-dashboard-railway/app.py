from flask import Flask, render_template, render_template_string
import mysql.connector
import os

app = Flask(__name__)


def get_db_connection():
    return mysql.connector.connect(
        host=os.environ.get('MYSQLHOST', 'localhost'),
        user=os.environ.get('MYSQLUSER', 'kali'),
        password=os.environ.get('MYSQLPASSWORD', 'kali'),
        database=os.environ.get('MYSQLDATABASE', 'threat_dashboard'),
        port=int(os.environ.get('MYSQLPORT', 3306))
    )


def get_db_data():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT url, phish_id, online, target
            FROM phishing_urls
            ORDER BY id DESC
            LIMIT 50
        """)
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
        print(f"Fetched {len(rows)} rows from database.")
        return rows
    except Exception as e:
        print("Error fetching data:", e)
        return []


@app.route('/')
def index():
    data = get_db_data()
    return render_template('index.html', threats=data)


@app.route('/refresh-table')
def refresh_table():
    data = get_db_data()
    return render_template_string("""
        {% for row in threats %}
        <tr>
            <td class="url-cell">{{ row[0] }}</td>
            <td class="phish-id">{{ row[1] }}</td>
            <td>
                {% if row[2] == "online" %}
                    <span class="status status-online">
                        <i class="fas fa-exclamation-circle"></i> Active
                    </span>
                {% else %}
                    <span class="status status-offline">
                        <i class="fas fa-ban"></i> Inactive
                    </span>
                {% endif %}
            </td>
            <td><span class="target-badge">{{ row[3] }}</span></td>
        </tr>
        {% endfor %}
    """, threats=data)


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
