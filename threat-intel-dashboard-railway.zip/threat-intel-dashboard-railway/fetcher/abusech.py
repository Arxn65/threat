import os
import io
import csv
import socket
import zipfile
import requests
import mysql.connector
from urllib.parse import urlparse


def get_db_connection():
    return mysql.connector.connect(
        host=os.environ.get('MYSQLHOST', 'localhost'),
        user=os.environ.get('MYSQLUSER', 'kali'),
        password=os.environ.get('MYSQLPASSWORD', 'kali'),
        database=os.environ.get('MYSQLDATABASE', 'threat_dashboard'),
        port=int(os.environ.get('MYSQLPORT', 3306))
    )


def resolve_ip(url):
    """Resolve a URL's hostname to an IP address."""
    try:
        parsed = urlparse(url)
        domain = parsed.hostname
        if not domain:
            return None
        return socket.gethostbyname(domain)
    except Exception:
        return None


def fetch_abusech_data():
    """Download latest threat data from Abuse.ch and store in database."""
    abuse_url = "https://urlhaus.abuse.ch/downloads/csv/"

    try:
        print("📡 Connecting to Abuse.ch...")
        response = requests.get(abuse_url, timeout=30)

        if response.status_code != 200:
            print(f"❌ Failed to fetch ZIP. HTTP status: {response.status_code}")
            return

        print("📦 Extracting ZIP archive...")
        zip_content = io.BytesIO(response.content)

        with zipfile.ZipFile(zip_content) as archive:
            csv_file = None
            for name in archive.namelist():
                if name.endswith(".csv") or name.endswith(".txt"):
                    csv_file = archive.open(name)
                    print(f"📥 Reading file: {name}")
                    break

            if csv_file is None:
                print("❌ No CSV file found in ZIP archive.")
                return

            text_stream = io.TextIOWrapper(csv_file, encoding="utf-8", newline='')
            reader = csv.reader(
                (line for line in text_stream if not line.startswith("#")),
                delimiter=",",
                quotechar='"'
            )

            row_count = 0
            max_rows = 50  # Increase this number to show more threats

            conn = get_db_connection()
            cursor = conn.cursor()

            # Clear old data so dashboard always shows fresh results
            cursor.execute("DELETE FROM phishing_urls")
            conn.commit()
            print("🧹 Cleared old records. Inserting fresh data...")

            for row in reader:
                if not row or row[0].startswith("#"):
                    continue

                try:
                    phish_id    = row[0].strip()
                    url_val     = row[2].strip()
                    url_status  = row[3].strip()
                    threat_type = row[5].strip()

                    cursor.execute("""
                        INSERT INTO phishing_urls (url, phish_id, online, target)
                        VALUES (%s, %s, %s, %s)
                    """, (url_val, phish_id[:100], url_status, threat_type))

                    conn.commit()
                    print(f"✅ [{row_count + 1}] {url_val} [{threat_type}]")
                    row_count += 1

                    if row_count >= max_rows:
                        print(f"🛑 Reached limit of {max_rows} rows.")
                        break

                except Exception as insert_err:
                    print(f"⚠️ Skipping row: {insert_err}")
                    conn.rollback()

            cursor.close()
            conn.close()
            print(f"✅ Successfully inserted {row_count} fresh threat records.")

    except Exception as fetch_err:
        print(f"❌ Error fetching Abuse.ch data: {fetch_err}")
