# 🛡️ Threat Intelligence Dashboard

A real-time phishing URL monitoring dashboard built with Flask + MySQL.
Fetches live threat data from [Abuse.ch URLhaus](https://urlhaus.abuse.ch/) every 30 seconds.

---

## 🚀 Run Locally

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Set up MySQL
```bash
mysql -u root -p < db/init_db.sql
```

### 3. Start the web server (Terminal 1)
```bash
python app.py
```

### 4. Start the data fetcher (Terminal 2)
```bash
python scheduler.py
```

### 5. Open browser
```
http://localhost:5000
```

---

## ☁️ Deploy on Railway (Free)

1. Push this repo to GitHub
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Add a MySQL database service
4. Set these environment variables in your app service:

| Variable        | Value (from Railway MySQL) |
|-----------------|---------------------------|
| MYSQLHOST       | from Railway              |
| MYSQLUSER       | from Railway              |
| MYSQLPASSWORD   | from Railway              |
| MYSQLDATABASE   | threat_dashboard          |
| MYSQLPORT       | 3306                      |

5. In Railway MySQL Query tab, run `db/init_db.sql`
6. Generate a domain → your dashboard is live!

---

## 📁 Project Structure

```
threat-intel-dashboard/
├── app.py              → Flask web server
├── scheduler.py        → Fetches threats every 30 seconds
├── requirements.txt    → Python dependencies
├── Procfile            → Railway startup commands
├── fetcher/
│   └── abusech.py      → Abuse.ch data fetcher
├── db/
│   └── init_db.sql     → Database setup
└── templates/
    └── index.html      → Dashboard UI
```
