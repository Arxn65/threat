import time
from fetcher.abusech import fetch_abusech_data

FETCH_INTERVAL = 30  # seconds


def main():
    print("🚀 Scheduler started.")
    while True:
        print("⏳ Fetching Abuse.ch data...")
        fetch_abusech_data()
        print(f"✅ Done. Next fetch in {FETCH_INTERVAL} seconds...\n")
        time.sleep(FETCH_INTERVAL)


if __name__ == "__main__":
    main()
